﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgSeqImps
{
    public class Alg
    {
        public string name = "";

        public Alg(string name)
        {
            this.name = name;
        }

        public virtual void Run()
        {

        }
    }
}
